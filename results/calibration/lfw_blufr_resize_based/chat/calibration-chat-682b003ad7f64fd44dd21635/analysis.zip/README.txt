Derived BLUFR-split calibration, not the BLUFR benchmark.
Calibration gallery=100 by default; released test gallery=1000. Size mismatch is intentional.
Trials/ratios/fit-safety seeds overlap: ranges are descriptive, not independent CIs.
Detailed fitted models, paired CIs, scores, codecs and assignments remain in SQLite.
Completed jobs: 1 / 5600
